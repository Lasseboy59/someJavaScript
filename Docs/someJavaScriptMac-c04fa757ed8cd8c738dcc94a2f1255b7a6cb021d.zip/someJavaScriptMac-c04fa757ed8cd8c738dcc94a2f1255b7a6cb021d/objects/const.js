const person = {
    age: 27
}



person.age = 20

// person = {}

console.log(person)