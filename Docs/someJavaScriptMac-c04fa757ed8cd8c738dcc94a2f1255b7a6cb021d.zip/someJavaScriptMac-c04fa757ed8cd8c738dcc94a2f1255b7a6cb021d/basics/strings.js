// let firstName = 'Lasse'
// let lastName = 'Järvinen'
// console.log(firstName + ' ' + lastName)

// CountQueuingStrategy, country, location

let city = 'Vantaa'
let county = 'Finland'
let location = 'Hämevaaa'

console.log(`${city}, ${county} at ${location} ` )