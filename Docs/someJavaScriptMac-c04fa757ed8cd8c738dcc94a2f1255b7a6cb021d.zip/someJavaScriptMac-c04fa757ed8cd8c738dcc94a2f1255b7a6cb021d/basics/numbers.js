let number = 5.5
let number2 = 2
console.log(number / number2)
    