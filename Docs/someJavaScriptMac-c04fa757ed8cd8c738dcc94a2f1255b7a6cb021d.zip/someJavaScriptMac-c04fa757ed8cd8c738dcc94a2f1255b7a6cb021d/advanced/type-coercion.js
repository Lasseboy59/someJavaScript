// Type coercion - a string, a number, a boolean

console.log('5' + 5)
console.log('5' - 5)
console.log('5' === 5)

// const type = typeof {}
// console.log(type)

const value = true + 12
const type = typeof value
console.log(type)
console.log(value)
